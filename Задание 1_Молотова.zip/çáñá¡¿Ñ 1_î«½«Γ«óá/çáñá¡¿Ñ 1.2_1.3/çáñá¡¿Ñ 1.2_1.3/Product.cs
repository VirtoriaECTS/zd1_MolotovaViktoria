﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Задание_1._2_1._3
{
    internal class Product
    {
        public decimal price { get; set; }
        public string name { get; set; }

        public Product(string Name, decimal Price)
        {
            this.name = Name;
            this.price = Price;
        }
        public string GetInfo()
        {
            return $"Наименование: {name}; Цена: {price}";
        }
    }
}
